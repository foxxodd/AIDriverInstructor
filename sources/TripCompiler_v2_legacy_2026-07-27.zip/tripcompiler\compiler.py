from __future__ import annotations

import argparse
import html
import json
import math
import re
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import pandas as pd


ALIASES = {
    "gps_altitude": [r"^Высота \(GPS\)$", r"GPS.*Altitude"],
    "gps_speed": [r"^Скорость \(GPS\)$", r"GPS.*Speed"],
    "vehicle_speed": [r"^Скорость автомобиля$", r"^\[ECM\] Скорость автомобиля$"],
    "steering_angle": [r"Угол поворота рулевого колеса", r"Steering.*Angle"],
    "yaw_rate": [r"^Значение рыскания$", r"^Датчик рыскания$", r"Yaw.*Rate"],
    "longitudinal_accel": [r"Продольная составляющая ускорения", r"Longitudinal.*Accel"],
    "lateral_accel": [r"Боковая составляющая ускорения", r"Lateral.*Accel"],
    "wheel_speed_fl": [r"частоты вращения левого переднего колеса", r"Front Left.*Wheel.*Speed"],
    "wheel_speed_fr": [r"частоты вращения правого переднего колеса", r"Front Right.*Wheel.*Speed"],
    "wheel_speed_rl": [r"частоты вращения левого заднего колеса", r"Rear Left.*Wheel.*Speed"],
    "wheel_speed_rr": [r"частоты вращения правого заднего колеса", r"Rear Right.*Wheel.*Speed"],
    "wheel_accel_fl": [r"Ускорение левого переднего колеса"],
    "wheel_accel_fr": [r"Ускорение правого переднего колеса"],
    "wheel_accel_rl": [r"Ускорение левого заднего колеса"],
    "wheel_accel_rr": [r"Ускорение правого заднего колеса"],
    "brake_switch": [r"выключателя стоп-сигнала", r"Brake.*Switch"],
    "parking_brake": [r"стояночного тормоза", r"Parking.*Brake"],
    "abs_active": [r"ABS\. Управление.*колесом", r"ABS.*Control"],
    "trc_active": [r"TRC\. Состояние управления", r"TRC.*Control"],
    "vsc_active": [r"VSC\. Управление.*колесом", r"VSC.*Control"],
}


@dataclass
class Config:
    sample_hz: float = 1.0
    map_margin_m: float = 250.0
    road_width_m: float = 7.0
    min_stop_s: float = 5.0
    stop_speed_kph: float = 1.0
    accel_event_mps2: float = 1.8
    brake_event_mps2: float = -2.2
    min_promote_samples: int = 20
    max_promote_gap_s: float = 10.0


def read_log(path: Path) -> pd.DataFrame:
    last_error = None
    for encoding in ("utf-8-sig", "utf-8", "cp1251"):
        try:
            df = pd.read_csv(path, sep=";", encoding=encoding)
            break
        except UnicodeError as exc:
            last_error = exc
    else:
        raise ValueError(f"Не удалось определить кодировку: {last_error}")
    df = df.loc[:, ~df.columns.astype(str).str.startswith("Unnamed")].copy()
    required = {"SECONDS", "PID", "VALUE", "LATITUDE", "LONGTITUDE"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Нет обязательных столбцов: {sorted(missing)}")
    for col in ("SECONDS", "VALUE", "LATITUDE", "LONGTITUDE"):
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["SECONDS"] = df["SECONDS"].astype(float)
    df["PID"] = df["PID"].astype("string").str.strip()
    df["UNITS"] = df.get("UNITS", pd.Series(index=df.index, dtype="string")).astype("string")
    df = df.dropna(subset=["SECONDS", "PID"]).sort_values("SECONDS").reset_index(drop=True)
    return df


def canonical_pid(pid: str) -> str | None:
    for canonical, patterns in ALIASES.items():
        if any(re.search(pattern, pid, flags=re.IGNORECASE) for pattern in patterns):
            return canonical
    return None


def signal_quality(part: pd.DataFrame, trip_start: float, trip_end: float, cfg: Config) -> dict:
    p = part.dropna(subset=["VALUE"]).sort_values("SECONDS")
    count = len(p)
    unique = int(p["VALUE"].nunique())
    span = float(p["SECONDS"].iloc[-1] - p["SECONDS"].iloc[0]) if count > 1 else 0.0
    gaps = p["SECONDS"].diff().dropna()
    median_gap = float(gaps.median()) if len(gaps) else None
    max_gap = float(gaps.max()) if len(gaps) else None
    trip_span = max(trip_end - trip_start, 1e-9)
    coverage = span / trip_span
    promotable = (
        count >= cfg.min_promote_samples
        and unique >= 2
        and median_gap is not None
        and median_gap <= cfg.max_promote_gap_s
        and coverage >= 0.5
    )
    if promotable:
        status = "usable"
    elif count < cfg.min_promote_samples:
        status = "too_sparse"
    elif unique < 2:
        status = "constant"
    elif coverage < 0.5:
        status = "partial_trip"
    else:
        status = "large_gaps"
    return {
        "samples": count,
        "unique_values": unique,
        "first_time_s": float(p["SECONDS"].iloc[0] - trip_start) if count else None,
        "last_time_s": float(p["SECONDS"].iloc[-1] - trip_start) if count else None,
        "span_s": span,
        "trip_coverage": coverage,
        "median_gap_s": median_gap,
        "max_gap_s": max_gap,
        "status": status,
        "promoted_to_telemetry": promotable,
    }


def build_pid_catalog(df: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    trip_start, trip_end = float(df.SECONDS.min()), float(df.SECONDS.max())
    rows = []
    for (pid, units), part in df.groupby(["PID", "UNITS"], dropna=False):
        quality = signal_quality(part, trip_start, trip_end, cfg)
        rows.append({
            "pid": pid,
            "canonical_name": canonical_pid(str(pid)),
            "units": None if pd.isna(units) else units,
            **quality,
            "min": float(part.VALUE.min()) if part.VALUE.notna().any() else None,
            "max": float(part.VALUE.max()) if part.VALUE.notna().any() else None,
            "mean": float(part.VALUE.mean()) if part.VALUE.notna().any() else None,
        })
    return pd.DataFrame(rows).sort_values(
        ["promoted_to_telemetry", "samples"], ascending=[False, False]
    )


def _rolling(values: pd.Series, window: int) -> pd.Series:
    return values.rolling(window, center=True, min_periods=1).median()


def build_trajectory(df: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    gps = df.dropna(subset=["LATITUDE", "LONGTITUDE"]).copy()
    gps["SECONDS"] = gps["SECONDS"].astype(float)
    gps = gps[
        (gps.LATITUDE.between(-90, 90))
        & (gps.LONGTITUDE.between(-180, 180))
        & (gps.LATITUDE.abs() > 1)
        & (gps.LONGTITUDE.abs() > 1)
    ]
    if gps.empty:
        raise ValueError("В логе нет валидных GPS-координат")
    coords = gps.groupby("SECONDS", as_index=False).agg(
        latitude=("LATITUDE", "median"), longitude=("LONGTITUDE", "median")
    )
    alt = df[df.PID.map(lambda x: canonical_pid(str(x)) == "gps_altitude")]
    alt = alt.groupby("SECONDS", as_index=False).VALUE.median().rename(columns={"VALUE": "altitude_m"})
    speed = df[df.PID.map(lambda x: canonical_pid(str(x)) == "gps_speed")]
    speed = speed.groupby("SECONDS", as_index=False).VALUE.median().rename(columns={"VALUE": "gps_speed_kph"})
    source = pd.merge_asof(coords.sort_values("SECONDS"), alt.sort_values("SECONDS"), on="SECONDS",
                           direction="nearest", tolerance=2.0)
    source = pd.merge_asof(source, speed.sort_values("SECONDS"), on="SECONDS",
                           direction="nearest", tolerance=2.0)
    source = source.drop_duplicates("SECONDS").sort_values("SECONDS")
    start, end = float(source.SECONDS.min()), float(source.SECONDS.max())
    dt = 1.0 / cfg.sample_hz
    grid = np.arange(start, end + dt * 0.5, dt)
    out = pd.DataFrame({"SECONDS": grid})
    for col in ("latitude", "longitude", "altitude_m", "gps_speed_kph"):
        valid = source[["SECONDS", col]].dropna()
        if len(valid) >= 2:
            out[col] = np.interp(grid, valid.SECONDS, valid[col])
        else:
            out[col] = np.nan
    out["latitude"] = _rolling(out.latitude, 5)
    out["longitude"] = _rolling(out.longitude, 5)
    out["altitude_m"] = _rolling(out.altitude_m, 11)
    lat0 = math.radians(float(out.latitude.iloc[0]))
    lon0 = math.radians(float(out.longitude.iloc[0]))
    earth = 6_378_137.0
    east = earth * (np.radians(out.longitude) - lon0) * math.cos(lat0)
    north = earth * (np.radians(out.latitude) - lat0)
    out["x_m"] = east - east.min() + cfg.map_margin_m
    out["y_m"] = north - north.min() + cfg.map_margin_m
    out["z_m"] = out.altitude_m - out.altitude_m.iloc[0]
    dx = np.gradient(out.x_m, dt)
    dy = np.gradient(out.y_m, dt)
    position_speed = np.hypot(dx, dy) * 3.6
    gps_speed = out.gps_speed_kph.clip(lower=0)
    out["speed_kph"] = gps_speed.where(gps_speed.notna(), position_speed)
    out["speed_kph"] = _rolling(out.speed_kph, 5)
    out["speed_mps"] = out.speed_kph / 3.6
    heading = np.degrees(np.arctan2(dx, dy)) % 360
    unwrapped = np.unwrap(np.radians(heading))
    out["heading_deg"] = np.degrees(_rolling(pd.Series(unwrapped), 5)) % 360
    out["accel_mps2"] = np.gradient(out.speed_mps, dt)
    out["accel_mps2"] = _rolling(out.accel_mps2, 5)
    out["yaw_rate_deg_s"] = np.degrees(np.gradient(unwrapped, dt))
    out["grade_percent"] = np.divide(
        np.gradient(out.z_m, dt),
        np.maximum(out.speed_mps, 0.5),
    ) * 100
    out["is_stopped"] = out.speed_kph < cfg.stop_speed_kph
    out["time_s"] = out.SECONDS - start
    cols = [
        "time_s", "x_m", "y_m", "z_m", "latitude", "longitude", "altitude_m",
        "speed_kph", "speed_mps", "heading_deg", "accel_mps2", "yaw_rate_deg_s",
        "grade_percent", "is_stopped",
    ]
    return out[cols]


def promote_signals(df: pd.DataFrame, trajectory: pd.DataFrame, catalog: pd.DataFrame) -> pd.DataFrame:
    result = trajectory.copy()
    usable = catalog[(catalog.promoted_to_telemetry) & catalog.canonical_name.notna()]
    source_start = float(df.SECONDS.min())
    target_abs = result.time_s.to_numpy() + source_start
    for canonical in usable.canonical_name.unique():
        pids = usable.loc[usable.canonical_name == canonical, "pid"]
        part = df[df.PID.isin(pids)].dropna(subset=["VALUE"]).sort_values("SECONDS")
        part = part.groupby("SECONDS", as_index=False).VALUE.median()
        if len(part) >= 2:
            result[canonical] = np.interp(target_abs, part.SECONDS, part.VALUE)
    return result


def detect_runs(mask: pd.Series, time: pd.Series, min_duration: float) -> list[tuple[int, int]]:
    groups = mask.ne(mask.shift()).cumsum()
    runs = []
    for _, idx in mask[mask].groupby(groups).groups.items():
        idx = list(idx)
        if float(time.iloc[idx[-1]] - time.iloc[idx[0]]) >= min_duration:
            runs.append((idx[0], idx[-1]))
    return runs


def build_events(t: pd.DataFrame, cfg: Config) -> list[dict]:
    events = []
    for start, end in detect_runs(t.is_stopped, t.time_s, cfg.min_stop_s):
        events.append({
            "type": "stop", "start_s": float(t.time_s.iloc[start]),
            "end_s": float(t.time_s.iloc[end]),
            "duration_s": float(t.time_s.iloc[end] - t.time_s.iloc[start]),
            "x_m": float(t.x_m.iloc[start]), "y_m": float(t.y_m.iloc[start]),
        })
    for kind, mask in (
        ("hard_acceleration", t.accel_mps2 >= cfg.accel_event_mps2),
        ("hard_braking", t.accel_mps2 <= cfg.brake_event_mps2),
    ):
        for start, end in detect_runs(mask, t.time_s, 1.0):
            segment = t.iloc[start:end + 1]
            peak = segment.accel_mps2.max() if kind == "hard_acceleration" else segment.accel_mps2.min()
            events.append({
                "type": kind, "start_s": float(segment.time_s.iloc[0]),
                "end_s": float(segment.time_s.iloc[-1]), "peak_accel_mps2": float(peak),
                "x_m": float(segment.x_m.iloc[0]), "y_m": float(segment.y_m.iloc[0]),
            })
    return sorted(events, key=lambda x: x["start_s"])


def path_length_m(t: pd.DataFrame) -> float:
    return float(np.hypot(t.x_m.diff(), t.y_m.diff()).sum())


def write_report(output: Path, summary: dict, catalog: pd.DataFrame) -> None:
    selected = catalog[catalog.canonical_name.notna()].copy()
    rows = "\n".join(
        f"<tr><td>{html.escape(str(r.canonical_name))}</td><td>{html.escape(str(r.pid))}</td>"
        f"<td>{r.samples}</td><td>{html.escape(str(r.status))}</td></tr>"
        for r in selected.itertuples()
    )
    report = f"""<!doctype html><html lang="ru"><meta charset="utf-8">
<title>TripCompiler report</title>
<style>body{{font-family:Arial;max-width:1100px;margin:32px auto}}table{{border-collapse:collapse;width:100%}}
td,th{{border:1px solid #bbb;padding:6px;text-align:left}}th{{background:#eee}}</style>
<h1>TripCompiler v2 — отчёт</h1>
<pre>{html.escape(json.dumps(summary, ensure_ascii=False, indent=2))}</pre>
<h2>Распознанные динамические сигналы</h2>
<table><tr><th>Каноническое имя</th><th>PID</th><th>Значений</th><th>Статус</th></tr>{rows}</table>
</html>"""
    (output / "report.html").write_text(report, encoding="utf-8")


def compile_trip(input_path: Path, output: Path, cfg: Config) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    df = read_log(input_path)
    catalog = build_pid_catalog(df, cfg)
    trajectory = build_trajectory(df, cfg)
    telemetry = promote_signals(df, trajectory, catalog)
    events = build_events(telemetry, cfg)
    dynamics = df[df.PID.map(lambda x: canonical_pid(str(x))).notna()].copy()
    dynamics["canonical_name"] = dynamics.PID.map(lambda x: canonical_pid(str(x)))
    dynamics["time_s"] = dynamics.SECONDS - df.SECONDS.min()
    dynamics = dynamics[
        ["time_s", "canonical_name", "PID", "VALUE", "UNITS", "LATITUDE", "LONGTITUDE"]
    ]
    script = {
        "path": [
            {"x": round(float(r.x_m), 3), "y": round(float(r.y_m), 3),
             "z": round(float(r.z_m), 3), "t": round(float(r.time_s), 3)}
            for r in telemetry.itertuples()
        ]
    }
    road_step = max(1, int(round(5 * cfg.sample_hz)))
    road = {
        "format": "TripCompiler road centerline v1",
        "note": "Промежуточный формат; не является Terrain And Road Importer.",
        "width_m": cfg.road_width_m,
        "nodes": [
            [round(float(r.x_m), 3), round(float(r.y_m), 3),
             round(float(r.z_m), 3), cfg.road_width_m]
            for r in telemetry.iloc[::road_step].itertuples()
        ],
    }
    summary = {
        "compiler_version": "2.0.0",
        "source_file": input_path.name,
        "raw_rows": int(len(df)),
        "pid_count": int(df.PID.nunique()),
        "duration_s": float(telemetry.time_s.iloc[-1]),
        "trajectory_points": int(len(telemetry)),
        "distance_km": path_length_m(telemetry) / 1000,
        "max_speed_kph": float(telemetry.speed_kph.max()),
        "altitude_min_m": float(telemetry.altitude_m.min()),
        "altitude_max_m": float(telemetry.altitude_m.max()),
        "event_count": len(events),
        "promoted_dynamic_signals": catalog.loc[
            catalog.promoted_to_telemetry & catalog.canonical_name.notna(), "canonical_name"
        ].dropna().unique().tolist(),
        "sparse_dynamic_signals": catalog.loc[
            ~catalog.promoted_to_telemetry & catalog.canonical_name.notna(),
            ["canonical_name", "pid", "samples", "status"]
        ].to_dict("records"),
    }
    telemetry.to_csv(output / "telemetry.csv", index=False, encoding="utf-8-sig")
    dynamics.to_csv(output / "vehicle_dynamics_raw.csv", index=False, encoding="utf-8-sig")
    catalog.to_csv(output / "pid_catalog.csv", index=False, encoding="utf-8-sig")
    (output / "script_ai.json").write_text(
        json.dumps(script, ensure_ascii=False, separators=(",", ":")), encoding="utf-8"
    )
    (output / "road_centerline.json").write_text(
        json.dumps(road, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (output / "events.json").write_text(
        json.dumps(events, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (output / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (output / "compiler_config.json").write_text(
        json.dumps(asdict(cfg), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_report(output, summary, catalog)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Car Scanner CSV -> BeamNG trip bundle")
    parser.add_argument("input", type=Path)
    parser.add_argument("-o", "--output", type=Path, default=Path("compiled_trip"))
    parser.add_argument("--sample-hz", type=float, default=1.0)
    parser.add_argument("--road-width", type=float, default=7.0)
    args = parser.parse_args()
    cfg = Config(sample_hz=args.sample_hz, road_width_m=args.road_width)
    summary = compile_trip(args.input, args.output, cfg)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
