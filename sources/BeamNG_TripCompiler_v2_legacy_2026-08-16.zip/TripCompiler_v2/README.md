# TripCompiler v2

Преобразует длинный CSV Car Scanner в проверяемый комплект телеметрии и
траекторию ScriptAI для обычной BeamNG.drive.

## Запуск

```powershell
py -3.10 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python tripcompiler.py "C:\path\trip.csv" -o compiled_trip
```

Опции:

```text
--sample-hz 1
--road-width 7
```

## Результаты

- `script_ai.json` — `{ "path": [{"x","y","z","t"}, ...] }` для ScriptAI;
- `telemetry.csv` — GPS-траектория, скорость, heading, ускорение, уклон;
- `vehicle_dynamics_raw.csv` — распознанные исходные PID без выдуманной интерполяции;
- `pid_catalog.csv` — частота, покрытие, вариативность и статус каждого PID;
- `events.json` — остановки, резкие ускорения и торможения;
- `road_centerline.json` — промежуточная ось дороги;
- `summary.json`, `report.html`, `compiler_config.json`.

## Важное поведение v2

Новый PID добавляется в синхронизированную `telemetry.csv` только когда:

- получено не менее 20 значений;
- сигнал не постоянный;
- покрыта хотя бы половина поездки;
- медианный интервал не больше 10 секунд.

Разреженные угол руля, yaw rate, ускорения и скорости колёс остаются в
`vehicle_dynamics_raw.csv` и помечаются в `pid_catalog.csv`. Это исключает
ложную реконструкцию динамики по единичным значениям.

`road_centerline.json` не является форматом Terrain And Road Importer:
этот импортёр относится к BeamNG.tech. Для обычной BeamNG.drive файл служит
исходником будущего генератора нативного уровня/DecalRoad.

## Тестовая физическая дорога для Gridmap

Компилятор создаёт `test_road.dae`: простую дорожную ленту с collision mesh,
которая повторяет координаты и высоту ScriptAI.

```powershell
python tripcompiler.py "C:\path\trip.csv" -o compiled_trip `
  --road-width 10 `
  --map-z-margin 5 `
  --test-road-point-distance 1 `
  --test-road-z-offset 0.45 `
  --test-road-thickness 0.25
```

- `--road-width` — ширина ленты в метрах;
- `--map-z-margin` — высота нижней точки маршрута над плоскостью Gridmap;
- `--test-road-point-distance` — минимальный шаг сечений меша;
- `--test-road-z-offset` — положение поверхности ниже точек ScriptAI;
- `--test-road-thickness` — толщина физической ленты.

В BeamNG World Editor создайте `TSStatic`, выберите `test_road.dae`, оставьте
Position `0 0 0`, Rotation `0 0 0`, Scale `1 1 1` и включите collision.

## OpenStreetMap + GPS-высоты

Для построения дорожной сети и рельефа выбранного прямоугольника используйте
`tripcompiler_osm.py`. Подробная инструкция: [OSM_LEVEL.md](OSM_LEVEL.md).
