# Уровень BeamNG из OpenStreetMap и GPS-высот

## 1. Получить прямоугольник OSM

Вариант без сетевого запроса TripCompiler:

1. Открыть openstreetmap.org.
2. Выбрать `Экспорт`.
3. Задать прямоугольник.
4. Сохранить файл как `area.osm`.

Либо передать координаты прямоугольника TripCompiler в порядке
`west,south,east,north`.

## 2. Собрать поездки

CSV Car Scanner поместить в `drive_logs`. Можно передать несколько `--track`.
Все поездки должны иметь GPS-координаты и PID `Высота (GPS)`.

## 3. Компиляция из локального OSM

```powershell
python tripcompiler_osm.py `
  --osm-file "C:\maps\area.osm" `
  --track "C:\projects\AIDriverInstructor\drive_logs\trip1.csv" `
  --track "C:\projects\AIDriverInstructor\drive_logs\trip2.csv" `
  --level-name prado_osm_test `
  --target-level gridmap_v2 `
  --terrain-size 512 `
  -o "C:\projects\AIDriverInstructor\compiled_trips\prado_osm_test"
```

## 4. Компиляция с загрузкой OSM по прямоугольнику

```powershell
python tripcompiler_osm.py `
  --bbox "132.95,42.95,133.05,43.05" `
  --track "C:\path\trip.csv" `
  --level-name prado_osm_test `
  -o "C:\projects\AIDriverInstructor\compiled_trips\prado_osm_test"
```

## Результат

- `roads_with_elevation.json` — дороги OSM с высотами GPS;
- `gps_elevation_samples.csv` — использованные точки высот;
- `level_manifest.json` — размеры, настройки и процент покрытия дорог;
- `terrain_heightmap.png` — 16-битный рельеф BeamNG;
- `osm_roads.dae` — простые физические дорожные ленты;
- `BEAMNG_IMPORT.txt` — параметры импорта конкретного пакета.

Готовая структура для User Folder находится внутри:

```text
beamng_mod\mods\unpacked\<level-name>\levels\<target-level>\...
```

## Важное ограничение

`coverage_percent` показывает долю дорожных точек, рядом с которыми реально
проходил GPS-трек. Высоты остальных дорог экстраполируются от ближайшей поездки
и не должны считаться точными.

Данные дорог: © OpenStreetMap contributors, ODbL.
