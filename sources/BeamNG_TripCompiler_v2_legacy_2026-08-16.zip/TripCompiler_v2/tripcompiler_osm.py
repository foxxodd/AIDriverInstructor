import argparse
import json
from pathlib import Path

from tripcompiler.osm_level import OSMLevelConfig, compile_osm_level, download_osm


def parse_bbox(value: str):
    parts = [float(part.strip()) for part in value.split(",")]
    if len(parts) != 4:
        raise argparse.ArgumentTypeError("bbox: west,south,east,north")
    west, south, east, north = parts
    if not (-180 <= west < east <= 180 and -90 <= south < north <= 90):
        raise argparse.ArgumentTypeError("Некорректный bbox")
    return west, south, east, north


def main():
    parser = argparse.ArgumentParser(description="OSM + GPS tracks -> BeamNG level bundle")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--osm-file", type=Path)
    source.add_argument("--bbox", type=parse_bbox, help="west,south,east,north")
    parser.add_argument("--track", type=Path, action="append", required=True)
    parser.add_argument("-o", "--output", type=Path, required=True)
    parser.add_argument("--level-name", default="osm_gps_test")
    parser.add_argument("--target-level", default="gridmap_v2")
    parser.add_argument("--terrain-size", type=int, default=512)
    parser.add_argument("--gps-match-radius", type=float, default=30.0)
    parser.add_argument("--road-point-spacing", type=float, default=10.0)
    parser.add_argument("--road-width", type=float, default=7.0)
    args = parser.parse_args()

    osm_path = args.osm_file
    if args.bbox:
        osm_path = args.output / "source_osm" / "area.osm"
        download_osm(args.bbox, osm_path)
    cfg = OSMLevelConfig(
        level_name=args.level_name,
        target_level=args.target_level,
        terrain_size=args.terrain_size,
        gps_match_radius_m=args.gps_match_radius,
        default_road_width_m=args.road_width,
        road_point_spacing_m=args.road_point_spacing,
    )
    result = compile_osm_level(osm_path, args.track, args.output, cfg)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
