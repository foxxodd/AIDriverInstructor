from __future__ import annotations

import json
import math
import shutil
import struct
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import zlib
from collections import deque
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from .compiler import read_log


DRIVABLE_HIGHWAYS = {
    "motorway",
    "motorway_link",
    "trunk",
    "trunk_link",
    "primary",
    "primary_link",
    "secondary",
    "secondary_link",
    "tertiary",
    "tertiary_link",
    "unclassified",
    "residential",
    "living_street",
    "service",
    "road",
    "track",
}

DEFAULT_WIDTHS = {
    "motorway": 14.0,
    "trunk": 12.0,
    "primary": 10.0,
    "secondary": 9.0,
    "tertiary": 8.0,
    "residential": 7.0,
    "living_street": 6.0,
    "service": 5.0,
    "track": 4.0,
}


@dataclass
class OSMLevelConfig:
    level_name: str = "osm_gps_test"
    target_level: str = "gridmap_v2"
    default_road_width_m: float = 7.0
    gps_match_radius_m: float = 30.0
    gps_sample_distance_m: float = 3.0
    road_point_spacing_m: float = 10.0
    road_z_offset_m: float = 0.10
    road_thickness_m: float = 0.25
    map_margin_m: float = 50.0
    map_z_margin_m: float = 5.0
    terrain_size: int = 512
    terrain_smoothing_iterations: int = 40


@dataclass
class OSMWay:
    osm_id: str
    node_ids: list[str]
    tags: dict[str, str]


def download_osm(bbox: tuple[float, float, float, float], output: Path) -> None:
    west, south, east, north = bbox
    query = f'[out:xml][timeout:120];(way["highway"]({south},{west},{north},{east});>;);out body;'
    request = urllib.request.Request(
        "https://overpass-api.de/api/interpreter",
        data=urllib.parse.urlencode({"data": query}).encode("utf-8"),
        headers={"User-Agent": "AI-Driving-Instructor-TripCompiler/3.0"},
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(request, timeout=180) as response:
        output.write_bytes(response.read())


def parse_osm(path: Path) -> tuple[dict[str, tuple[float, float]], list[OSMWay]]:
    root = ET.parse(path).getroot()
    nodes = {
        node.attrib["id"]: (float(node.attrib["lat"]), float(node.attrib["lon"]))
        for node in root.findall("node")
    }
    ways: list[OSMWay] = []
    for way in root.findall("way"):
        tags = {tag.attrib["k"]: tag.attrib["v"] for tag in way.findall("tag")}
        if tags.get("highway") not in DRIVABLE_HIGHWAYS:
            continue
        node_ids = [node.attrib["ref"] for node in way.findall("nd")]
        node_ids = [node_id for node_id in node_ids if node_id in nodes]
        if len(node_ids) >= 2:
            ways.append(OSMWay(way.attrib["id"], node_ids, tags))
    if not ways:
        raise ValueError("В OSM-файле не найдены автомобильные дороги highway=*")
    return nodes, ways


def _track_elevation_samples(path: Path) -> pd.DataFrame:
    frame = read_log(path)
    gps = frame.dropna(subset=["LATITUDE", "LONGTITUDE"])
    coords = gps.groupby("SECONDS", as_index=False).agg(
        latitude=("LATITUDE", "median"), longitude=("LONGTITUDE", "median")
    )
    altitude_mask = frame.PID.astype(str).str.contains(
        r"Высота \(GPS\)|GPS.*Altitude", case=False, regex=True
    )
    altitude = (
        frame.loc[altitude_mask]
        .groupby("SECONDS", as_index=False)
        .VALUE.median()
        .rename(columns={"VALUE": "altitude_m"})
    )
    result = pd.merge_asof(
        coords.sort_values("SECONDS"),
        altitude.sort_values("SECONDS"),
        on="SECONDS",
        direction="nearest",
        tolerance=3.0,
    ).dropna(subset=["altitude_m"])
    result["altitude_m"] = result.altitude_m.rolling(11, center=True, min_periods=1).median()
    result["source"] = path.name
    return result


def load_track_samples(paths: list[Path]) -> pd.DataFrame:
    samples = pd.concat([_track_elevation_samples(path) for path in paths], ignore_index=True)
    samples = samples[
        samples.latitude.between(-90, 90)
        & samples.longitude.between(-180, 180)
        & samples.altitude_m.between(-500, 9000)
    ].copy()
    if samples.empty:
        raise ValueError("В поездках нет совместных GPS-координат и GPS-высоты")
    return samples


def _project(
    latitude: np.ndarray, longitude: np.ndarray, lat0: float, lon0: float
) -> tuple[np.ndarray, np.ndarray]:
    earth = 6_378_137.0
    x = earth * np.radians(longitude - lon0) * math.cos(math.radians(lat0))
    y = earth * np.radians(latitude - lat0)
    return x, y


def _road_width(tags: dict[str, str], cfg: OSMLevelConfig) -> float:
    try:
        width = float(tags.get("width", "").replace(",", ".").split()[0])
        if 2 <= width <= 40:
            return width
    except (ValueError, IndexError):
        pass
    try:
        lanes = int(tags.get("lanes", ""))
        if 1 <= lanes <= 8:
            return max(3.5, lanes * 3.5)
    except ValueError:
        pass
    highway = tags.get("highway", "")
    base = highway.removesuffix("_link")
    return DEFAULT_WIDTHS.get(base, cfg.default_road_width_m)


def _downsample_xy(samples: pd.DataFrame, minimum_distance: float) -> pd.DataFrame:
    kept: list[int] = []
    last_by_source: dict[str, np.ndarray] = {}
    for row in samples.itertuples():
        point = np.array([row.x_m, row.y_m])
        previous = last_by_source.get(row.source)
        if previous is None or np.linalg.norm(point - previous) >= minimum_distance:
            kept.append(row.Index)
            last_by_source[row.source] = point
    return samples.loc[kept].reset_index(drop=True)


def _estimate_elevation(
    x: float, y: float, gps_xy: np.ndarray, gps_z: np.ndarray, radius: float
) -> tuple[float, float, int]:
    distances = np.hypot(gps_xy[:, 0] - x, gps_xy[:, 1] - y)
    inside = np.flatnonzero(distances <= radius)
    if inside.size:
        nearest = inside[np.argsort(distances[inside])[:8]]
        weights = 1.0 / np.maximum(distances[nearest], 1.0) ** 2
        elevation = float(np.average(gps_z[nearest], weights=weights))
        return elevation, float(distances[nearest].min()), int(nearest.size)
    nearest = int(np.argmin(distances))
    return float(gps_z[nearest]), float(distances[nearest]), 0


def build_elevated_roads(
    nodes: dict[str, tuple[float, float]],
    ways: list[OSMWay],
    samples: pd.DataFrame,
    cfg: OSMLevelConfig,
) -> tuple[list[dict], dict]:
    latitudes = np.array([lat for lat, _ in nodes.values()])
    longitudes = np.array([lon for _, lon in nodes.values()])
    lat0, lon0 = float(latitudes.min()), float(longitudes.min())
    node_ids = list(nodes)
    node_x, node_y = _project(latitudes, longitudes, lat0, lon0)
    projected_nodes = {
        node_id: (float(x + cfg.map_margin_m), float(y + cfg.map_margin_m))
        for node_id, x, y in zip(node_ids, node_x, node_y)
    }
    gps_x, gps_y = _project(samples.latitude.to_numpy(), samples.longitude.to_numpy(), lat0, lon0)
    samples = samples.copy()
    samples["x_m"] = gps_x + cfg.map_margin_m
    samples["y_m"] = gps_y + cfg.map_margin_m
    world_size_x = float(node_x.max() - node_x.min() + cfg.map_margin_m * 2)
    world_size_y = float(node_y.max() - node_y.min() + cfg.map_margin_m * 2)
    outside_margin = max(100.0, cfg.gps_match_radius_m * 2)
    samples = samples[
        samples.x_m.between(-outside_margin, world_size_x + outside_margin)
        & samples.y_m.between(-outside_margin, world_size_y + outside_margin)
    ].copy()
    if samples.empty:
        raise ValueError("GPS-треки не пересекают выбранную область OSM")
    samples = _downsample_xy(samples, cfg.gps_sample_distance_m)
    gps_xy = samples[["x_m", "y_m"]].to_numpy()
    gps_z = samples.altitude_m.to_numpy()

    roads: list[dict] = []
    matched_nodes = 0
    total_nodes = 0
    match_distances: list[float] = []
    for way in ways:
        centerline = [projected_nodes[node_id] for node_id in way.node_ids]
        dense_centerline: list[tuple[float, float]] = []
        for segment_index in range(len(centerline) - 1):
            start = np.array(centerline[segment_index])
            end = np.array(centerline[segment_index + 1])
            count = max(
                1, int(math.ceil(np.linalg.norm(end - start) / max(1.0, cfg.road_point_spacing_m)))
            )
            for step in range(count):
                point = start + (end - start) * (step / count)
                dense_centerline.append((float(point[0]), float(point[1])))
        dense_centerline.append(centerline[-1])
        points = []
        for x, y in dense_centerline:
            elevation, distance, nearby = _estimate_elevation(
                x, y, gps_xy, gps_z, cfg.gps_match_radius_m
            )
            points.append([x, y, elevation, distance, nearby])
            total_nodes += 1
            match_distances.append(distance)
            if nearby:
                matched_nodes += 1
        roads.append(
            {
                "osm_id": way.osm_id,
                "name": way.tags.get("name", ""),
                "highway": way.tags.get("highway", "road"),
                "width_m": _road_width(way.tags, cfg),
                "points": points,
                "tags": way.tags,
            }
        )

    minimum_altitude = min(point[2] for road in roads for point in road["points"])
    z_shift = cfg.map_z_margin_m - minimum_altitude
    for road in roads:
        for point in road["points"]:
            point[2] += z_shift
    samples["z_m"] = samples.altitude_m + z_shift
    coverage = {
        "road_count": len(roads),
        "road_nodes": total_nodes,
        "nodes_with_gps_within_radius": matched_nodes,
        "coverage_percent": round(100 * matched_nodes / max(total_nodes, 1), 2),
        "gps_match_radius_m": cfg.gps_match_radius_m,
        "median_nearest_gps_distance_m": round(float(np.median(match_distances)), 2),
        "maximum_nearest_gps_distance_m": round(float(np.max(match_distances)), 2),
        "elevation_shift_m": z_shift,
        "origin": {"latitude": lat0, "longitude": lon0},
        "world_size_x_m": world_size_x,
        "world_size_y_m": world_size_y,
    }
    return roads, {"coverage": coverage, "samples": samples}


def _mesh_from_roads(roads: list[dict], cfg: OSMLevelConfig):
    vertices: list[tuple[float, float, float]] = []
    faces: list[tuple[int, int, int]] = []
    for road in roads:
        points = [np.array(point[:3], dtype=float) for point in road["points"]]
        if len(points) < 2:
            continue
        half_width = road["width_m"] / 2
        top = []
        for index, point in enumerate(points):
            previous = points[max(0, index - 1)]
            following = points[min(len(points) - 1, index + 1)]
            tangent = following[:2] - previous[:2]
            length = np.linalg.norm(tangent)
            tangent = tangent / length if length > 1e-6 else np.array([1.0, 0.0])
            lateral = np.array([-tangent[1], tangent[0]]) * half_width
            z = point[2] + cfg.road_z_offset_m
            top.extend(
                [
                    (point[0] + lateral[0], point[1] + lateral[1], z),
                    (point[0] - lateral[0], point[1] - lateral[1], z),
                ]
            )
        base = len(vertices)
        vertices.extend(top)
        vertices.extend([(x, y, z - cfg.road_thickness_m) for x, y, z in top])
        bottom = base + len(top)
        for index in range(len(points) - 1):
            l0, r0 = base + index * 2, base + index * 2 + 1
            l1, r1 = l0 + 2, r0 + 2
            bl0, br0 = bottom + index * 2, bottom + index * 2 + 1
            bl1, br1 = bl0 + 2, br0 + 2
            faces.extend(
                [
                    (l0, r0, l1),
                    (r0, r1, l1),
                    (bl0, bl1, br0),
                    (br0, bl1, br1),
                    (l0, l1, bl0),
                    (l1, bl1, bl0),
                    (r0, br0, r1),
                    (r1, br0, br1),
                ]
            )
    return vertices, faces


def write_roads_dae(path: Path, roads: list[dict], cfg: OSMLevelConfig) -> dict:
    vertices, faces = _mesh_from_roads(roads, cfg)
    positions = " ".join(f"{value:.6g}" for vertex in vertices for value in vertex)
    indices = " ".join(str(index) for face in faces for index in face)
    xml = f'''<?xml version="1.0" encoding="utf-8"?>
<COLLADA xmlns="http://www.collada.org/2005/11/COLLADASchema" version="1.4.1">
  <asset><unit name="meter" meter="1"/><up_axis>Z_UP</up_axis></asset>
  <library_effects><effect id="road-effect"><profile_COMMON><technique sid="common"><lambert><diffuse><color>0.35 0.35 0.35 1</color></diffuse></lambert></technique></profile_COMMON></effect></library_effects>
  <library_materials><material id="road-material" name="test_road"><instance_effect url="#road-effect"/></material></library_materials>
  <library_geometries><geometry id="roads-mesh" name="osm_roads"><mesh>
    <source id="road-positions"><float_array id="road-positions-array" count="{len(vertices) * 3}">{positions}</float_array><technique_common><accessor source="#road-positions-array" count="{len(vertices)}" stride="3"><param name="X" type="float"/><param name="Y" type="float"/><param name="Z" type="float"/></accessor></technique_common></source>
    <vertices id="road-vertices"><input semantic="POSITION" source="#road-positions"/></vertices>
    <triangles material="test_road" count="{len(faces)}"><input semantic="VERTEX" source="#road-vertices" offset="0"/><p>{indices}</p></triangles>
  </mesh></geometry></library_geometries>
  <library_visual_scenes><visual_scene id="Scene" name="Scene"><node id="base00" name="base00"><node id="start01" name="start01"><node id="osm_roads" name="osm_roads"><instance_geometry url="#roads-mesh"><bind_material><technique_common><instance_material symbol="test_road" target="#road-material"/></technique_common></bind_material></instance_geometry></node><node id="Colmesh-1" name="Colmesh-1"><instance_geometry url="#roads-mesh"/></node></node></node></visual_scene></library_visual_scenes>
  <scene><instance_visual_scene url="#Scene"/></scene>
</COLLADA>'''
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(xml, encoding="utf-8")
    return {"vertices": len(vertices), "triangles": len(faces)}


def _png_chunk(chunk_type: bytes, data: bytes) -> bytes:
    return (
        struct.pack(">I", len(data))
        + chunk_type
        + data
        + struct.pack(">I", zlib.crc32(chunk_type + data) & 0xFFFFFFFF)
    )


def write_png16(path: Path, values: np.ndarray) -> None:
    height, width = values.shape
    rows = b"".join(b"\x00" + row.astype(">u2").tobytes() for row in values)
    png = b"\x89PNG\r\n\x1a\n"
    png += _png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 16, 0, 0, 0, 0))
    png += _png_chunk(b"IDAT", zlib.compress(rows, 9))
    png += _png_chunk(b"IEND", b"")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(png)


def build_heightmap(
    samples: pd.DataFrame,
    size: int,
    smoothing_iterations: int,
    world_size_x: float,
    world_size_y: float,
):
    if size < 128 or size > 4096 or size & (size - 1):
        raise ValueError("terrain-size должен быть степенью двойки от 128 до 4096")
    world_size = max(world_size_x, world_size_y)
    grid = np.full((size, size), np.nan, dtype=float)
    counts = np.zeros((size, size), dtype=np.int32)
    px = np.clip(np.rint(samples.x_m / max(world_size, 1) * (size - 1)).astype(int), 0, size - 1)
    py = np.clip(np.rint(samples.y_m / max(world_size, 1) * (size - 1)).astype(int), 0, size - 1)
    rows = size - 1 - py  # север находится сверху PNG
    for row, col, elevation in zip(rows, px, samples.z_m):
        if np.isnan(grid[row, col]):
            grid[row, col] = elevation
        else:
            grid[row, col] += elevation
        counts[row, col] += 1
    seeded = counts > 0
    grid[seeded] /= counts[seeded]
    if not seeded.any():
        raise ValueError("Нет GPS-высот для heightmap")
    queue = deque(zip(*np.nonzero(seeded)))
    visited = seeded.copy()
    while queue:
        row, col = queue.popleft()
        for next_row, next_col in ((row - 1, col), (row + 1, col), (row, col - 1), (row, col + 1)):
            if 0 <= next_row < size and 0 <= next_col < size and not visited[next_row, next_col]:
                grid[next_row, next_col] = grid[row, col]
                visited[next_row, next_col] = True
                queue.append((next_row, next_col))
    fixed = grid.copy()
    for _ in range(max(0, smoothing_iterations)):
        neighbors = (
            np.roll(grid, 1, 0) + np.roll(grid, -1, 0) + np.roll(grid, 1, 1) + np.roll(grid, -1, 1)
        ) / 4
        grid = neighbors
        grid[seeded] = fixed[seeded]
    max_height = max(10.0, math.ceil(float(grid.max()) + 5))
    encoded = np.clip(np.rint(grid / max_height * 65535), 0, 65535).astype(np.uint16)
    return encoded, {
        "max_height_m": max_height,
        "world_size_m": world_size,
        "source_area_x_m": world_size_x,
        "source_area_y_m": world_size_y,
        "meters_per_pixel": world_size / (size - 1),
    }


def compile_osm_level(
    osm_path: Path, track_paths: list[Path], output: Path, cfg: OSMLevelConfig
) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    stored_osm = output / "source_osm" / "area.osm"
    if osm_path.resolve() != stored_osm.resolve():
        stored_osm.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(osm_path, stored_osm)
    nodes, ways = parse_osm(osm_path)
    samples = load_track_samples(track_paths)
    roads, elevation = build_elevated_roads(nodes, ways, samples, cfg)
    mod_root = output / "beamng_mod" / "mods" / "unpacked" / cfg.level_name
    level_root = mod_root / "levels" / cfg.target_level
    dae_path = level_root / "art" / "shapes" / cfg.level_name / "osm_roads.dae"
    heightmap_path = level_root / "art" / "terrains" / cfg.level_name / "terrain_heightmap.png"
    mesh = write_roads_dae(dae_path, roads, cfg)
    heightmap, terrain = build_heightmap(
        elevation["samples"],
        cfg.terrain_size,
        cfg.terrain_smoothing_iterations,
        elevation["coverage"]["world_size_x_m"],
        elevation["coverage"]["world_size_y_m"],
    )
    write_png16(heightmap_path, heightmap)
    elevation["samples"].to_csv(output / "gps_elevation_samples.csv", index=False)
    (output / "roads_with_elevation.json").write_text(
        json.dumps(roads, ensure_ascii=False), encoding="utf-8"
    )
    manifest = {
        "format": "TripCompiler OSM+GPS BeamNG bundle v1",
        "osm_source": "source_osm/area.osm",
        "tracks": [path.name for path in track_paths],
        "attribution": "© OpenStreetMap contributors — https://www.openstreetmap.org/copyright",
        "config": asdict(cfg),
        "mesh": mesh,
        "terrain": terrain,
        **elevation["coverage"],
    }
    (output / "level_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    instructions = f"""BeamNG.drive 0.30 import

1. Copy the contents of:
   {mod_root}
   into the BeamNG user folder, preserving mods/unpacked/... structure.
2. Open {cfg.target_level}, press F11 and open Asset Browser.
3. Add /levels/{cfg.target_level}/art/shapes/{cfg.level_name}/osm_roads.dae.
4. Position 0 0 0, rotation 0 0 0, scale 1 1 1; collision type: Collision Mesh.
5. Terrain heightmap:
   /levels/{cfg.target_level}/art/terrains/{cfg.level_name}/terrain_heightmap.png
   Import as 16-bit heightmap, Max Height={terrain["max_height_m"]} m.
   Square terrain size: {terrain["world_size_m"]:.1f} m.
   Meters per Pixel: {terrain["meters_per_pixel"]:.4f}.
   If north/south is mirrored, enable Flip Y.

Data attribution: © OpenStreetMap contributors — https://www.openstreetmap.org/copyright
"""
    (output / "BEAMNG_IMPORT.txt").write_text(instructions, encoding="utf-8")
    return manifest
