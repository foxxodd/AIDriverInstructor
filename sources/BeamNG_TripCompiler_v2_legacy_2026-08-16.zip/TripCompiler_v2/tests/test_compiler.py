import json
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

import pandas as pd

from tripcompiler.compiler import Config, canonical_pid, compile_trip


class CompilerTests(unittest.TestCase):
    def test_aliases(self):
        self.assertEqual(canonical_pid("Угол поворота рулевого колеса"), "steering_angle")
        self.assertEqual(
            canonical_pid("Показания датчика частоты вращения правого заднего колеса"),
            "wheel_speed_rr",
        )

    def test_minimal_compile(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            rows = []
            for t in range(30):
                rows.extend(
                    [
                        [t, "Высота (GPS)", 100 + t / 10, "m", 43 + t * 1e-5, 133 + t * 1e-5],
                        [t, "Скорость (GPS)", 20, "km/h", 43 + t * 1e-5, 133 + t * 1e-5],
                    ]
                )
            source = root / "log.csv"
            pd.DataFrame(
                rows, columns=["SECONDS", "PID", "VALUE", "UNITS", "LATITUDE", "LONGTITUDE"]
            ).to_csv(source, sep=";", index=False)
            out = root / "out"
            summary = compile_trip(source, out, Config())
            self.assertEqual(summary["trajectory_points"], 30)
            self.assertIn("path", json.loads((out / "script_ai.json").read_text()))
            self.assertTrue((out / "test_road.dae").is_file())
            self.assertGreater(summary["test_road_mesh"]["vertices"], 0)
            self.assertGreater(summary["test_road_mesh"]["triangles"], 0)
            dae = ET.parse(out / "test_road.dae")
            names = {
                node.attrib.get("name")
                for node in dae.getroot().iter()
                if node.tag.endswith("node")
            }
            self.assertIn("trip_test_road", names)
            self.assertIn("Colmesh-1", names)


if __name__ == "__main__":
    unittest.main()
