import json
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

import pandas as pd

from tripcompiler.osm_level import OSMLevelConfig, compile_osm_level, parse_osm


OSM = """<?xml version="1.0" encoding="UTF-8"?>
<osm version="0.6">
  <node id="1" lat="43.00000" lon="133.00000"/>
  <node id="2" lat="43.00010" lon="133.00010"/>
  <node id="3" lat="43.00020" lon="133.00020"/>
  <node id="4" lat="43.00010" lon="133.00000"/>
  <way id="10">
    <nd ref="1"/><nd ref="2"/><nd ref="3"/>
    <tag k="highway" v="residential"/><tag k="name" v="Test road"/>
  </way>
  <way id="11">
    <nd ref="1"/><nd ref="4"/><tag k="highway" v="footway"/>
  </way>
</osm>"""


class OSMLevelTests(unittest.TestCase):
    def test_compile_osm_level(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            osm = root / "area.osm"
            osm.write_text(OSM, encoding="utf-8")
            rows = []
            for index in range(3):
                lat = 43 + index * 0.0001
                lon = 133 + index * 0.0001
                rows.extend(
                    [
                        [index, "GPS Altitude", 100 + index * 2, "m", lat, lon],
                        [index, "GPS Speed", 20, "km/h", lat, lon],
                    ]
                )
            track = root / "track.csv"
            pd.DataFrame(
                rows, columns=["SECONDS", "PID", "VALUE", "UNITS", "LATITUDE", "LONGTITUDE"]
            ).to_csv(track, sep=";", index=False)
            output = root / "out"
            manifest = compile_osm_level(
                osm,
                [track],
                output,
                OSMLevelConfig(terrain_size=128, terrain_smoothing_iterations=2),
            )
            self.assertEqual(manifest["road_count"], 1)
            self.assertEqual(manifest["coverage_percent"], 100.0)
            dae = next(output.rglob("osm_roads.dae"))
            ET.parse(dae)
            png = next(output.rglob("terrain_heightmap.png"))
            self.assertEqual(png.read_bytes()[:8], b"\x89PNG\r\n\x1a\n")
            roads = json.loads((output / "roads_with_elevation.json").read_text())
            self.assertGreater(roads[0]["points"][-1][2], roads[0]["points"][0][2])

    def test_filters_non_drivable_ways(self):
        with tempfile.TemporaryDirectory() as td:
            osm = Path(td) / "area.osm"
            osm.write_text(OSM, encoding="utf-8")
            _, ways = parse_osm(osm)
            self.assertEqual([way.osm_id for way in ways], ["10"])


if __name__ == "__main__":
    unittest.main()
